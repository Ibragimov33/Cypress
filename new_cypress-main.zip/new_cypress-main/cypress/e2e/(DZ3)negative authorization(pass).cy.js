describe('Проверка авторизации', function () {

    it('Проверка на негативный кейс авторизации(Пароль):', function () {
        cy.visit('https://login.qa.studio//'); // Зашли на сайт 
        cy.get('#mail').type('german@dolnikov.ru'); // Нашли поле с мылом и ввели верный логин
        cy.get('#pass').type('iLoveqastudio123'); // Нашли поле с паролем и ввели НЕверный пароль 
        cy.get('#loginButton').click(); // Нажали на кнопку войти
        cy.get('#messageHeader').should('be.visible'); // Проверка на видимость текста
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); // Нашли текст и проверили его на нужный ответ
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // Проверка, что есть крестик и он видимый
    })
})
 
 // запуск через теринал: npx cypress run --spec cypress/e2e/poke.cy.js --browser chrome