describe('Проверка авторизации', function () {

    it('Проверка логики восстановления пароля', function () {
         cy.visit('https://login.qa.studio//'); // Зашли на сайт 
         cy.get('#forgotEmailButton').click(); // Нашли кнопку "Забыли пароль?" и кликнули на него 
         cy.get('#mailForgot').type('german@dolnikov.ru'); // Нашли поле ввода логина и ввели логин
         cy.get('#restoreEmailButton').click(); // Нашли кнопку "Отправить код" и кликнули на нее 
         cy.get('#messageHeader').should('be.visible'); // Проверка на видимость текста
         cy.get('#messageHeader').contains('Успешно отправили пароль на e-mail'); // Нашли текст и проверили его на нужный ответ
         cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // Проверка, что есть крестик и он видимый 
 
     })
    })
 
 // запуск через теринал: npx cypress run --spec cypress/e2e/poke.cy.js --browser chrome