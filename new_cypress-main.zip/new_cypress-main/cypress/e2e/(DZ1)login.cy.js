describe('Проверка авторизации', function () {

    it('Верный пароль и верный логин', function () {
         cy.visit('https://login.qa.studio//'); // Зашли на сайт 
         cy.get('#mail').type('german@dolnikov.ru'); // Нашли поле с мылом и ввели верный логин
         cy.get('#pass').type('iLoveqastudio1'); // Нашли поле с паролем и ввели верный пароль 
         cy.get('#loginButton').click(); // Нажали на кнопку войти
         cy.get('#messageHeader').should('be.visible'); // Проверка на видимость текста
         cy.get('#messageHeader').contains('Авторизация прошла успешно'); // Проверка на нужный ответ 
         cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // Видимость крестика
 
     })
    })
 
 // запуск через теринал: npx cypress run --spec cypress/e2e/poke.cy.js --browser chrome