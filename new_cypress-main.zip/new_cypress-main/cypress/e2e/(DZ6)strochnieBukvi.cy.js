describe('Проверка авторизации', function () {

    it('Проверка на  приведение к строчным буквам в логине:', function () {
        cy.visit('https://login.qa.studio//'); // Зашли на сайт 
        cy.get('#mail').type('GerMan@Dolnikov.ru'); // Нашли поле с мылом и ввели  логин 
        cy.get('#pass').type('iLoveqastudio1'); // Нашли поле с паролем и ввели верный пароль 
        cy.get('#loginButton').click(); // Нажали на кнопку войти
        cy.get('#messageHeader').should('be.visible'); // Проверка на видимость текста
        cy.get('#messageHeader').contains('Авторизация прошла успешно'); // Нашли текст и проверили его на нужный ответ
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // Проверка, что есть крестик и он видимый
    })
})
 
 // запуск через теринал: npx cypress run --spec cypress/e2e/poke.cy.js --browser chrome