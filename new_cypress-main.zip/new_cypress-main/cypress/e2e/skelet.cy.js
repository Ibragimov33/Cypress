describe('НАЗВАНИЕ_ГРУППЫ_ТЕСТОВ', function () {

    it('НАЗВАНИЕ_ТЕСТ', function () {
         cy.visit('ДОМЕН');
     })
 }) 