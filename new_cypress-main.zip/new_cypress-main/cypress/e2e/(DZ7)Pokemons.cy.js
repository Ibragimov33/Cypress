describe('Проверка покупки нового аватара', function () {                 
    it('тест на  покупку нового аватара для своего тренера', function () {   // название теста
         cy.visit('https://pokemonbattle.ru/');                          // Зашли на сайт покемонов https://pokemonbattle.ru/
         cy.get('input[id="k_email"]').type('USER_LOGIN');                   // Нашли поле ввода логина и ввели верный логин
         cy.get('input[id="k_password"]').type('USER_PASSWORD');               // Нашли поле ввода пароля и ввели верный пароль
         cy.get('button[type="submit"]').click();                // нажимаем кнопку Войти
         cy.wait(2000);
         cy.get('.header_card_trainer').click();            // Нажимаем на аватар тренера
         cy.wait(2000);
         cy.get('.k_mobile > :nth-child(5) > #dropdown > img').click(); // нажимаем кнопку Смена аватара
         cy.get('.available > button').first().click();   // Нажимаем на кнопку купить у первого доступного аватара
         cy.get('.card_number').type('4003600000000014');                     // Нашли поле ввода карты и  вводим номер 
         cy.get('.card_csv').type('125');                             //  Нашли поле ввода CVV и вводим CVV карты
         cy.get('.card_date').type('1226');                           // Вводим срок действия карты
         cy.get('.card_name').type('Aydar Ibragimov');                           // Вводим имя владельца  карты
         cy.get('.style_1_base_button_payment_body > .style_1_base_button_payment').click();     // нажимаем кнопку Оплатить
         cy.wait(2000)
         cy.get('.style_1_base_input').type('56456');                            // вводим код подтверждения СМС
         cy.get('.style_1_base_button_payment_body > .style_1_base_button_payment').click();   // нажимаем кнопку Оплатить
         cy.contains('Покупка прошла успешно').should('be.visible');     // проверяем наличие и видимость сообщения об успешной покупке
     });
 });
